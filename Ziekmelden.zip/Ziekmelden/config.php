<?php

	$host="localhost";
	$dbname="llnsysteem";
	$username="root";
	$password="";
	
	$con = new PDO("mysql:host=$host;dbname=$dbname","$username","$password");

?>